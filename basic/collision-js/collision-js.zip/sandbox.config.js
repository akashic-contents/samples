var config = {
	"warn": {
		"es6": false
	}
};

module.exports = config;
