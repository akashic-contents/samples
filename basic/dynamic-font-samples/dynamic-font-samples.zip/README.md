# dynamic-font-samples

## 操作方法

各スライダーを操作することで、それぞれ

- 背景の色
- 背景の透過度
- 文字の色
- 文字の透過度

を変更できます。

## セッションパラメータ

```
[
	[
		32,
		null,
		":akashic",
		{
			type: "start",
			parameters: {
				text: "こんなに素敵な Akashic コンテンツ",
				textColor1: "#ffffff",
				textColor2: "#ff0000",
				backColor1: "#000000",
				backColor2: "#00ff00",
				hintColor: "#0000ff",
			},
		},
	],
]
```

によって以下の項目を設定できます。

| パラメータ名 | 設定内容     |
| ------------ | ------------ |
| text         | 表示テキスト |
| textColor1   | 文字色１     |
| textColor2   | 文字色２     |
| backColor1   | 背景色１     |
| backColor2   | 背景色２     |
| hintColor    | UI ヒント色  |

## sandbox.config.js

akashic-sandbox 上で利用できるセッションパラメータについて記述しています。

`sandbox.config.js` の詳細については以下を参照してください。

https://akashic-games.github.io/guide/sandbox-config.html

## 実行方法

以下のコマンドで実行できます。

```
npm install
npm start
```

## ライセンス

本リポジトリは MIT License の元で公開されています。
詳しくは [LICENSE](./LICENSE) をご覧ください。

ただし、画像ファイルおよび音声ファイルは
[CC BY 2.1 JP](https://creativecommons.org/licenses/by/2.1/jp/) の元で公開されています。
