"use strict";

var config = {
  autoSendEventName: "default",
  showMenu: false,
  events: {
    default: [
      [
        32,
        null,
        ":akashic",
        {
          type: "start",
          parameters: {}
        }
      ]
    ],
    custom: [
      [
        32,
        null,
        ":akashic",
        {
          type: "start",
          parameters: {
            text: "こんなに素敵なAkashicコンテンツ",
            textColor1: "#ffffff",
            textColor2: "#ff0000",
            backColor1: "#000000",
            backColor2: "#00ff00",
            hintColor: "#0000ff"
          }
        }
      ]
    ]
  }
};

module.exports = config;
