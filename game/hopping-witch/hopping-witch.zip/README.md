# これはなんですか

Akashic エンジンで作成したフラッピーバードクローンです。

# 実行方法

```sh
$ akashic-sandbox .
```

# ゲームルール

画面をタップすると魔女が飛び上がります。上手く障害物をかわしてください。進んだ距離が得点になります。

## ライセンス

本リポジトリは MIT License の元で公開されています。
詳しくは [LICENSE](./LICENSE) をご覧ください。

ただし、画像ファイルおよび音声ファイルは
[CC BY 2.1 JP](https://creativecommons.org/licenses/by/2.1/jp/) の元で公開されています。
