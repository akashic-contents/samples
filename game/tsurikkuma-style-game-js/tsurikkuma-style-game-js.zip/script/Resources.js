"use strict";

function getResources() {
  return g.game.vars.resouces;
}

function setResources(resouces) {
  g.game.vars.resouces = resouces;
}

exports.getResources = getResources;
exports.setResources = setResources;
