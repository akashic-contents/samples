"use strict";

var getResources = require("../Resources").getResources;
var Constants = require("../constants");

/**
 * 魚クラス
 */
function Fish(param) {
  // 泳ぐアニメーション用の Tween
  this._swimTween = null;
  this._parent = param.parent;
  this._label = this._createLabel(param);
  this._parent.append(this._label);
  this._isCaptured = false;
  this._score = param.score;
  this._swimmingStyle = param.swimmingStyle;
}

Fish.prototype.getName = function() {
  return this._label.text;
};

Fish.prototype.getScore = function() {
  return this._score;
};

Fish.prototype.getArea = function() {
  return {
    width: this._label.width,
    height: this._label.height,
    x: this._label.x,
    y: this._label.y
  };
};

Fish.prototype.destroy = function() {
  this._label.destroy();
};

/**
 * 釣られる
 */
Fish.prototype.followHook = function(fishingRod) {
  var that = this;
  this._label.update.add(function() {
    that._label.y = Math.min(fishingRod.getHookArea().y, that._label.y);
    that._label.modified();
  });
};

/**
 * 泳ぐ
 */
Fish.prototype.swim = function() {
  var that = this;
  var timeline = getResources().timeline;
  var toX = this._label.x < g.game.width / 2 ? g.game.width : -this._label.width;
  if (this._swimTween) {
    timeline.remove(this._swimTween);
  }
  this._swimTween = timeline
    .create(this._label)
    .moveTo(toX, this._label.y, this._swimmingStyle.swimTime)
    .call(function() {
      return that._label.destroy();
    });
};

/**
 * 泳ぎをやめる
 */
Fish.prototype.stop = function() {
  this._isCaptured = true;
  if (this._swimTween) {
    getResources().timeline.remove(this._swimTween);
    this._swimTween = null;
  }
};

/**
 * 魚ラベル作成
 */
Fish.prototype._createLabel = function(param) {
  var initPos = this._initialPos(param);
  return new g.Label({
    scene: param.parent.scene,
    text: param.name,
    font: getResources().font,
    fontSize: Constants.FISH_FONT_SIZE,
    x: initPos.x,
    y: initPos.y
  });
};

/**
 * 初期位置生成
 */
Fish.prototype._initialPos = function(param) {
  switch (param.swimmingStyle.pattern) {
    case "left_to_right":
      return { x: -Constants.FISH_FONT_SIZE, y: param.swimmingStyle.depth };
    case "right_to_left":
      return { x: g.game.width, y: param.swimmingStyle.depth };
  }
};

exports.Fish = Fish;
