"use strict";

var getResources = require("../Resources").getResources;
var Constants = require("../constants");

/**
 * 釣り竿クラス
 */
function FishingRod(param) {
  /**
   * スタック時のトリガー
   */
  this.onStuck = new g.Trigger();
  this._parent = param.parent;
  this._isCatching = false;
  this._isFishing = false;
  this._createRod();
  this._createRodString();
  this._createHook();
}

FishingRod.prototype.getHookArea = function() {
  return {
    width: this._hook.width,
    height: this._hook.height,
    x: this._hook.x,
    y: this._hook.y
  };
};

/**
 * 釣り上げる
 */
FishingRod.prototype.catchUp = function(finished) {
  var that = this;
  var timeline = getResources().timeline;

  if (this._isFishing || this._isCatching) return;
  this._isCatching = true;
  this._isFishing = true;

  timeline
    .create(this._rodString)
    .to({ height: Constants.ROD_STRING_HEIGHT_WHEN_UP }, Constants.FISHING_DURATION)
    .wait(Constants.FISHING_WAIT_DURATION);

  timeline
    .create(this._hook)
    .moveTo(this._hook.x, Constants.HOOK_POS_WHEN_UP.y, Constants.FISHING_DURATION)
    .wait(Constants.FISHING_WAIT_DURATION)
    .call(function() {
      that._isCatching = false;
      finished();
    });
};

/**
 * 釣った魚からパターンを判定
 */
FishingRod.prototype.getFishingPattern = function(capturedFishList) {
  var pattern = "Default";
  capturedFishList.forEach(function(fish) {
    if (pattern !== "Default") return;
    switch (fish.getName()) {
      case "くらげ":
        pattern = "Stuck";
        break;
    }
  });
  return pattern;
};

/**
 * パターンに従って釣りをする
 */
FishingRod.prototype.fishing = function(pattern) {
  switch (pattern) {
    case "Default":
      this._swingDown();
      break;
    case "Stuck":
      this._stuck();
      break;
  }
};

/**
 * 振り下ろす
 */
FishingRod.prototype._swingDown = function() {
  var that = this;
  var timeline = getResources().timeline;

  timeline.create(this._rodString).to({ height: Constants.ROD_STRING_SIZE.height }, Constants.FISHING_DURATION);

  timeline
    .create(this._hook)
    .moveTo(this._hook.x, Constants.HOOK_POS.y, Constants.FISHING_DURATION)
    .call(function() {
      that._isFishing = false;
    });
};

/**
 * スタックさせる
 */
FishingRod.prototype._stuck = function() {
  var that = this;
  var timeline = getResources().timeline;

  this.onStuck.fire();

  // ${STUCK_DURATION} ミリ秒後に、スタックを解除し、釣竿を振り下ろす
  timeline.create(this._rodString).wait(Constants.STUCK_DURATION);

  timeline
    .create(this._hook)
    .wait(Constants.STUCK_DURATION)
    .call(function() {
      that._swingDown();
    });
};

/**
 * 釣竿を作成する
 */
FishingRod.prototype._createRod = function() {
  new g.FilledRect({
    scene: this._parent.scene,
    cssColor: Constants.ROD_COLOR,
    width: Constants.ROD_SIZE.width,
    height: Constants.ROD_SIZE.height,
    x: Constants.ROD_POS.x,
    y: Constants.ROD_POS.y,
    angle: Constants.ROD_ANGLE,
    parent: this._parent
  });
};

/**
 * 釣り糸を作成する
 */
FishingRod.prototype._createRodString = function() {
  this._rodString = new g.FilledRect({
    scene: this._parent.scene,
    cssColor: Constants.ROD_STRING_COLOR,
    width: Constants.ROD_STRING_SIZE.width,
    height: Constants.ROD_STRING_SIZE.height,
    x: Constants.ROD_STRING_POS.x,
    y: Constants.ROD_STRING_POS.y,
    parent: this._parent
  });
};

/**
 * 釣り針を作成する
 */
FishingRod.prototype._createHook = function() {
  var scene = this._parent.scene;

  this._hook = new g.E({
    scene: scene,
    width: Constants.HOOK_SIZE.width,
    height: Constants.HOOK_SIZE.height,
    x: Constants.HOOK_POS.x,
    y: Constants.HOOK_POS.y,
    parent: this._parent
  });

  new g.FilledRect({
    scene: scene,
    cssColor: Constants.HOOK_COLOR,
    width: 10,
    height: this._hook.height,
    x: this._hook.width - 10,
    parent: this._hook
  });

  new g.FilledRect({
    scene: scene,
    cssColor: Constants.HOOK_COLOR,
    width: this._hook.width,
    height: 10,
    y: this._hook.height - 10,
    parent: this._hook
  });

  new g.FilledRect({
    scene: scene,
    cssColor: Constants.HOOK_COLOR,
    width: 10,
    height: 20,
    y: this._hook.height - 20,
    parent: this._hook
  });
};

exports.FishingRod = FishingRod;
