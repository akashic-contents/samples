"use strict";

var Fish = require("./Fish").Fish;
var Constants = require("../constants");

/**
 * 出現する魚の種類
 */
var fishInfoList = [
  { name: "さかな", score: 1 },
  { name: "くらげ", score: 0 }
];

/**
 * 海クラス
 */
function Sea(param) {
  this.capturedFishList = [];
  this._parent = param.parent;
  this._fishList = [];
}

/**
 * 定期的に魚を作成する
 */
Sea.prototype.startFishTimer = function() {
  var that = this;
  this._fishTimerIdentifier = this._parent.scene.setInterval(function() {
    var fish = that._createRandomFish(that._parent);
    fish.swim();
    that._fishList.push(fish);
  }, Constants.FISH_INTERVAL);
};

/**
 * タイマーをクリアする
 */
Sea.prototype.clearFishTimer = function() {
  if (!this._fishTimerIdentifier) return;
  this._parent.scene.clearInterval(this._fishTimerIdentifier);
  this._fishTimerIdentifier = null;
};

/**
 * 釣り針と魚の当たり判定をチェックする
 */
Sea.prototype.checkFishOnHook = function(fishingRod) {
  var that = this;
  if (!this._fishList.length) return;
  if (!fishingRod._isCatching) return;
  this._fishList.forEach(function(fish) {
    // 釣り針と魚が当たっていた場合は釣り上げる
    if (g.Collision.intersectAreas(fishingRod.getHookArea(), fish.getArea())) {
      if (fish._isCaptured) return;
      fish.stop();
      fish.followHook(fishingRod);
      that._fishList = that._fishList.filter(function(item) {
        return item !== fish;
      });
      that.capturedFishList.push(fish);
    }
  });
};

/**
 * 捕まえた魚たちを destroy する
 */
Sea.prototype.destroyCapturedFish = function() {
  this.capturedFishList.forEach(function(capturedFish) {
    return capturedFish.destroy();
  });
  this.capturedFishList = [];
};

/**
 * ランダムな魚を作成
 */
Sea.prototype._createRandomFish = function(parent) {
  // 作成する魚の種類
  var fishIdx = g.game.random.get(0, fishInfoList.length - 1);
  // 魚の泳ぎ方のパターン
  var pattern = g.game.random.get(0, 1) ? "right_to_left" : "left_to_right";
  // 魚が泳ぐ水深
  var depth = Constants.WATERSURFACE_POS.y + Constants.FISH_FONT_SIZE * g.game.random.get(0, 4);
  // 魚が泳ぐ時間
  var swimTime = g.game.random.get(Constants.SWIMMING_TIME_RANGE.min, Constants.SWIMMING_TIME_RANGE.max);
  return new Fish({
    parent: parent,
    name: fishInfoList[fishIdx].name,
    score: fishInfoList[fishIdx].score,
    swimmingStyle: {
      pattern: pattern,
      depth: depth,
      swimTime: swimTime
    }
  });
};

exports.Sea = Sea;
