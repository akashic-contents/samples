"use strict";

var Timeline = require("@akashic-extension/akashic-timeline").Timeline;
var getResources = require("./Resources").getResources;
var setResources = require("./Resources").setResources;
var Constants = require("./constants");
var Sea = require("./entity/Sea").Sea;
var FishingRod = require("./entity/FishingRod").FishingRod;
var HUDManager = require("./HUDManager").HUDManager;

/**
 * ゲームクラス
 */
function TsurikkumaStyleGame(scene) {
  this.scene = scene;
  this.root = new g.E({ scene: scene });
  this.scene.append(this.root);
  createStage(this.root);
  createBear(this.root);
  this.sea = createSea(this.root);
  this.fishingRod = createFishingRod(this.root);
  this.hudManager = createHUDManager(this.root);
}

/**
 * ゲームを開始する
 */
TsurikkumaStyleGame.prototype.start = function() {
  this.hudManager.startCountdown(
    function() {
      this._startGame();
    }.bind(this)
  );
};

/**
 * ゲームを1フレーム進める
 */
TsurikkumaStyleGame.prototype.step = function() {
  if (!this.isPlaying) return;
  this.sea.checkFishOnHook(this.fishingRod);
  this.hudManager.updateTime();
  if (this.hudManager.getNowTime() <= 0) {
    // ゲーム終了
    this.isPlaying = false;
    this._finishGame();
  }
};

/**
 * タップしたときの処理
 */
TsurikkumaStyleGame.prototype.onPointDown = function() {
  if (!this.isPlaying) return;
  this.fishingRod.catchUp(
    function() {
      var pattern = this.fishingRod.getFishingPattern(this.sea.capturedFishList);
      this.hudManager.addScore(this.hudManager.calcScore(this.sea.capturedFishList));
      this.fishingRod.fishing(pattern);
      this.sea.destroyCapturedFish();
    }.bind(this)
  );
};

/**
 * ゲーム本編開始
 */
TsurikkumaStyleGame.prototype._startGame = function() {
  this.isPlaying = true;
  this.sea.startFishTimer();
};

/**
 * ゲーム終了時の処理
 */
TsurikkumaStyleGame.prototype._finishGame = function() {
  this.scene.pointUpCapture.removeAll();
  this.sea.clearFishTimer();
  this.hudManager.showTimeUp();
  if (getResources().param.isAtsumaru) {
    var boardId = 1;
    window.RPGAtsumaru.experimental.scoreboards.setRecord(boardId, g.game.vars.gameState.score).then(function() {
      window.RPGAtsumaru.experimental.scoreboards.display(boardId);
    });
  }
};

function main(param) {
  var scene = new g.Scene({ game: g.game });
  var timeLimit = Constants.TIMELIMIT;
  if (param.sessionParameter.totalTimeLimit) {
    /*
     * セッションパラメータで制限時間が指定されたらその値を使用します
     * 制限時間の 10 秒ほど前にはゲーム上の演出が完了するようにします
     */
    timeLimit = Math.max(param.sessionParameter.totalTimeLimit - 10, 1);
  }
  setResources({
    timeline: new Timeline(scene),
    font: createFont(),
    timeLimit: timeLimit,
    param: param
  });
  var tsurikkumaStyleGame = new TsurikkumaStyleGame(scene);
  scene.loaded.add(function() {
    tsurikkumaStyleGame.start();
  });
  scene.update.add(function() {
    tsurikkumaStyleGame.step();
  });
  scene.pointDownCapture.add(function() {
    tsurikkumaStyleGame.onPointDown();
  });
  g.game.pushScene(scene);
}
exports.main = main;

/**
 * フォントを作成
 */
function createFont() {
  return new g.DynamicFont({
    game: g.game,
    fontFamily: Constants.FONT_FAMILY,
    size: Constants.FONT_SIZE
  });
}

/**
 * 背景を作成
 */
function createStage(parent) {
  /**
   * 背景 (空と海)
   */
  new g.FilledRect({
    scene: parent.scene,
    cssColor: Constants.BACKGROUND_COLOR,
    width: g.game.width,
    height: g.game.height,
    opacity: Constants.BACKGROUND_ALPHA,
    parent: parent
  });

  /**
   * 島
   */
  new g.FilledRect({
    scene: parent.scene,
    cssColor: Constants.ISLAND_COLOR,
    width: Constants.ISLAND_SIZE.width,
    height: Constants.ISLAND_SIZE.height,
    x: Constants.ISLAND_POS.x,
    y: Constants.ISLAND_POS.y,
    parent: parent
  });

  /**
   * 草
   */
  new g.FilledRect({
    scene: parent.scene,
    cssColor: Constants.GRASS_COLOR,
    width: Constants.GRASS_SIZE.width,
    height: Constants.GRASS_SIZE.height,
    x: Constants.GRASS_POS.x,
    y: Constants.GRASS_POS.y,
    parent: parent
  });

  /**
   * 水面
   */
  new g.FilledRect({
    scene: parent.scene,
    cssColor: Constants.WATERSURFACE_COLOR,
    width: g.game.width,
    height: 3,
    x: Constants.WATERSURFACE_POS.x,
    y: Constants.WATERSURFACE_POS.y,
    parent: parent
  });
}

/**
 * くまを作成
 */
function createBear(parent) {
  new g.FilledRect({
    scene: parent.scene,
    cssColor: Constants.BEAR_COLOR,
    width: Constants.BEAR_SIZE.width,
    height: Constants.BEAR_SIZE.height,
    x: Constants.BEAR_POS.x,
    y: Constants.BEAR_POS.y,
    parent: parent
  });
}

/**
 * 海を作成
 */
function createSea(parent) {
  return new Sea({ parent: parent });
}

/**
 * 釣竿を作成
 */
function createFishingRod(parent) {
  // 釣り針
  var fishingRod = new FishingRod({ parent: parent });
  fishingRod.onStuck.add(function() {
    createMissLabel(parent);
  });
  return fishingRod;
}

/**
 * HUDマネージャーを作成
 */
function createHUDManager(parent) {
  var hudManager = new HUDManager({
    scoreLabel: createScoreLabel(parent),
    timeLabel: createTimeLabel(parent),
    systemLabel: createSystemLabel(parent)
  });
  hudManager.setScore(0);
  hudManager.setTimeLimit(getResources().timeLimit);
  return hudManager;
}

/**
 * スコアラベルを作成
 */
function createScoreLabel(parent) {
  return new g.Label({
    scene: parent.scene,
    text: "",
    font: getResources().font,
    fontSize: Constants.FONT_SIZE,
    width: g.game.width - 10,
    y: 5,
    textAlign: g.TextAlign.Right,
    widthAutoAdjust: false,
    parent: parent
  });
}

/**
 * 制限時間ラベルを作成
 */
function createTimeLabel(parent) {
  return new g.Label({
    scene: parent.scene,
    text: "",
    font: getResources().font,
    fontSize: Constants.FONT_SIZE,
    width: g.game.width - 220,
    y: 5,
    textAlign: g.TextAlign.Right,
    widthAutoAdjust: false,
    parent: parent
  });
}

/**
 *  システムラベルを作成
 */
function createSystemLabel(parent) {
  return new g.Label({
    scene: parent.scene,
    text: "3",
    font: getResources().font,
    fontSize: Constants.FONT_SIZE * 2,
    x: g.game.width / 2,
    y: g.game.height / 2,
    anchorX: 0.5,
    anchorY: 0.5,
    parent: parent
  });
}

/**
 * 釣りミス時のラベルを作成
 */
function createMissLabel(parent) {
  var missLabel = new g.Label({
    scene: parent.scene,
    text: "miss!",
    textColor: "red",
    font: getResources().font,
    fontSize: Math.floor(Constants.FONT_SIZE / 2),
    x: Constants.BEAR_POS.x + Constants.BEAR_SIZE.width * 2,
    y: Constants.BEAR_POS.y,
    parent: parent
  });
  getResources()
    .timeline.create(missLabel)
    .wait(Constants.STUCK_DURATION)
    .call(function() {
      missLabel.destroy();
    });
}
