# raycaster-js サンプル

ライトとフォグの利用例です。

## 実行方法

次の手順を実行後、ブラウザで http://localhost:3000/game/ を開いてください。

```sh
npm install
npm run build
npm start
```

## 内容

ライトの方向と色が常に変化し、遠方を黒くするフォグが適用されたダンジョンが表示されます。

## 操作方法

画面左下の４つのボタンを押下すると、押したボタンに応じて視点が前後移動・左右回転します。

## ライセンス

本リポジトリは MIT License の元で公開されています。
詳しくは [LICENSE](./LICENSE) をご覧ください。

ただし、画像ファイルおよび音声ファイルは
[CC BY 2.1 JP](https://creativecommons.org/licenses/by/2.1/jp/) の元で公開されています。
