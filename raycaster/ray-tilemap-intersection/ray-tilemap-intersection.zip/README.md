# raycaster-js サンプル

レイとタイルマップ・床・天井の交差テストの利用例です。

## 実行方法

次の手順を実行後、ブラウザで http://localhost:3000/game/ を開いてください。

```sh
npm install
npm run build
npm start
```

## 内容

画面をクリックすると、クリックしたが壁の時は赤いマークが、床または天井の時は黄色いマークが表示されます。 同時に次の２つの情報が画面左上に表示されます。

- クリックされた位置の３次元空間での座標。
- クリックされた壁、床、天井の法線ベクトル。

raycaster-js の `screenPointToRay()` と `rayBillboardIntersection()` を利用しています。

`screenPointToRay()` でカメラ座標とスクリーン上のクリックされた座標を結ぶレイ（半直線）を生成し、 `rayTilemapCeilingFloorIntersection()` に渡すことで交差情報を求めています。

## 操作方法

画面左下の４つのボタンを押下すると、押したボタンに応じて視点が前後移動・左右回転します。

画面をクリックすると、クリックしたが壁の時は赤いマークが、床または天井の時は黄色いマークが表示されます。

## ライセンス

本リポジトリは MIT License の元で公開されています。
詳しくは [LICENSE](./LICENSE) をご覧ください。

ただし、画像ファイルおよび音声ファイルは
[CC BY 2.1 JP](https://creativecommons.org/licenses/by/2.1/jp/) の元で公開されています。
